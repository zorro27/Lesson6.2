//
//  ViewController.swift
//  SkillBox Lesson6.2
//
//  Created by Роман Зобнин on 13.01.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var myLabel: UILabel!
    
    @IBOutlet weak var myTextFild: UITextField!
    
    @IBAction func myButton(_ sender: Any) {
        let a = myTextFild.text!
        if Int(a) != nil {
            myLabel.text = String(Int(pow(2.0, Double (a)!)))
        } else {
            myLabel.text = "Введите целое число"
        }
    }
}

